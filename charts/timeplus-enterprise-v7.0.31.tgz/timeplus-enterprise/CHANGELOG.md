# develop

feat!: removed timeplus web (combined with appserver)
feat!: removed kv service

# v7

feat(timeplusd): added `extraEnvs`
feat(timeplusd): added `enableCoreDump` and `sleep`
feat(timeplusd): supported compute node
feat(timeplusd): provisioned `_timeplus_appserver_metastore` mutable stream for appserver
feat(timeplusd): supported 5 nodes deployment
feat(timeplusd): allowed to configure subpath for pv
feat(timeplusd): allowed to configure headless svc
feat(appserver)!: default to metastore type
feat: updated default docker image registry

# v6

## v6.0.7 (2025-03-24)

Timeplus Enterprise v2.7.3

## v6.0.6 (2025-03-20)

Timeplus Enterprise v2.7.2

- fix: with select to if selector

## v6.0.5 (2025-03-19)

Timeplus Enterprise v2.7.2

## v6.0.4 (2025-03-07)

Timeplus Enterprise v2.7.1

- feat: added annotations to all components
- feat(timeplusd): added service account

## v6.0.3 (2025-02-27)

Timeplus Enterprise v2.7.0

- feat(ingress)!: configured appserver and timeplusd separated
- feat!: removed default users
- feat: supported securityContext, added default fsGroup to timeplusd
- feat: added labels to svc
- feat(connector): write log to disk by default
- fix(timeplusd): timeplusd sts will restart if user config has been updated
- fix: updated monitor dashboard

# v5

## v5.0.11 (2025-03-24)

Timeplus Enterprise v2.6.6

## v5.0.5 (2025-01-14)

Timeplus Enterprise v2.6.0

- feat: added `prometheus_metrics` section to render vector sidecar
- feat: added timeplusd debug pod
- feat: default storage size to be 100Gi, log storage size to be 30Gi
- feat: log pv will be enabled by default, write log to stream storage if it is disabled
- feat: inject enterprise version
- fix: improved monitoring dashboard
- config: removed `timeplusd-replicas` and `blocked-users`

# v4

## v4.0.11 (2025-01-09)

Timeplus Enterprise v2.5.12
